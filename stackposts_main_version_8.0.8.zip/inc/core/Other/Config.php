<?php
return [
    'id' => 'other',
    'folder' => 'core',
    'name' => 'Other',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-plus-octagon',
    'color' => '#ff6f02'
];