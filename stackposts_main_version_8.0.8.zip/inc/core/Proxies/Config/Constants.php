<?php
defined('TB_PROXIES') || define('TB_PROXIES', 'sp_proxies');