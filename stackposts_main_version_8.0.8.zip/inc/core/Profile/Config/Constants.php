<?php
defined('TB_PAYMENT_HISTORY') || define('TB_PAYMENT_HISTORY', 'sp_payment_history');
