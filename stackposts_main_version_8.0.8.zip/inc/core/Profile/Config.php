<?php
return [
    'id' => 'profile',
    'folder' => 'core',
    'name' => 'Profile',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-id-card-alt',
    'color' => '#e90a7b',
    'require' => true
];