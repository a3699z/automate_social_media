<?php
return [
    'id' => 'proxy_system',
    'folder' => 'core',
    'name' => 'Proxy system',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-user-shield',
    'color' => '#ff4d3b',
    'role' => 1
];