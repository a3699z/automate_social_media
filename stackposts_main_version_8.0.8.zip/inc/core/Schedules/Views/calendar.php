<div class="d-lg-flex d-md-block d-sm-block d-xs-block d-block h-100">
	<div class="wp-50 schedule-calendar h-100 overflow-auto">
		<div class="calendar text-gray-800" id="schedule-calendar" data-result="html" data-content="column-three"></div>
	</div>
	<div class="wp-50 schedule-list overflow-auto">
		<?php _ec($list_schedules);?>
	</div>
</div>
