<?php return array (
  'Customize system interface' => 'Customize system interface',
  'Home' => 'Home',
);