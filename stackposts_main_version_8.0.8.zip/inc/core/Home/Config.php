<?php
return [
    'id' => 'home',
    'folder' => 'core',
    'name' => 'Home',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-home',
    'color' => '#28abf5'
];