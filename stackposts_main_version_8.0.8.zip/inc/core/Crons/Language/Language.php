<?php return array (
  'Search' => 'Search',
  'Customize system interface' => 'Customize system interface',
  'Crons' => 'Crons',
);