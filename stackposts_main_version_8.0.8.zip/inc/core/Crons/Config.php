<?php
return [
    'id' => 'crons',
    'folder' => 'core',
    'name' => 'Crons',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-brackets-curly',
    'color' => '#0e8500',
];