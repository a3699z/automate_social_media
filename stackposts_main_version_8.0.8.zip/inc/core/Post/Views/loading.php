<div class="d-flex flex-column justify-content-center align-items-center h-300 text-gray-500">
    <i class="fas fa-spinner fa-spin fs-70"></i>
    <div class="text-gray-500 fs-20 mt-3"><?php _e("Loading...")?></div>
</div>