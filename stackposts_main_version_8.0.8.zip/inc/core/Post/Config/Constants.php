<?php
defined('TB_POSTS') || define('TB_POSTS', 'sp_posts');