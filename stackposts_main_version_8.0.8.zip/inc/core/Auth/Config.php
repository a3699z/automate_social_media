<?php
return [
    'id' => 'auth',
    'folder' => 'core',
    'name' => 'Login & Auth',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-badge-check',
    'color' => '#292929',
    'require' => true
];