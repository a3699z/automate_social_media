<?php
namespace Core\Dashboard\Models;
use CodeIgniter\Model;

class DashboardModel extends Model
{
    
}
