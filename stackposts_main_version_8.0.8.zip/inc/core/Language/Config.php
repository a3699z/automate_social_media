<?php
return [
    'id' => 'language',
    'folder' => 'core',
    'name' => 'Language',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Configure your website',
    'icon' => 'fad fa-globe-americas',
    'color' => '#00d724',
    'role' => 1
];