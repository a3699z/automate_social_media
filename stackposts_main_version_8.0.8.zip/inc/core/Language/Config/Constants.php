<?php
defined('TB_LANGUAGE_CATEGORY') || define('TB_LANGUAGE_CATEGORY', 'sp_language_category');
defined('TB_LANGUAGE') || define('TB_LANGUAGE', 'sp_language');