<?php
defined('TB_PURCHASES') || define('TB_PURCHASES', 'sp_purchases');