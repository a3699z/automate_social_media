<?php
namespace Core\Plugins\Models;
use CodeIgniter\Model;

class PluginsModel extends Model
{
    
}
