<?php
defined('TB_ACCOUNTS') || define('TB_ACCOUNTS', 'sp_accounts');
defined('TB_ACCOUNT_SESSIONS') || define('TB_ACCOUNT_SESSIONS', 'sp_account_sessions');