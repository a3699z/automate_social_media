<?php return array (
  'Search' => 'Search',
  'Add account' => 'Add account',
  'Unofficial' => 'Unofficial',
  'Cookie' => 'Cookie',
  'Please select a profile' => 'Please select a profile',
  'Connect a Profile' => 'Connect a Profile',
  'Allow add profiles for' => 'Allow add profiles for',
  'You can only add up to %s profiles' => 'You can only add up to %s profiles',
  'Please select an item to delete' => 'Please select an item to delete',
  'Success' => 'Success',
  'Customize system interface' => 'Customize system interface',
  'Account manager' => 'Account manager',
);