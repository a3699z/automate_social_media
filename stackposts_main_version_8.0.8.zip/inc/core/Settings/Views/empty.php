<div class="mw-400 container d-flex align-items-center align-self-center h-100">
    <div>
        <div class="text-center px-4">
            <img class="mw-100 mh-300px" alt="" src="<?php _e( get_theme_url() ) ?>Assets/img/empty.png">
            <div class="d-lg-none d-md-none d-sm-block d-xs-block d-block">
                <a href="javascript:void(0);" class="btn btn-primary btn-sm mt-4 b-r-30 btn-open-sub-sidebar"><?php _e("Open menu")?></a>
            </div>
        </div>
    </div>
</div>