<?php
defined('TB_ROLES') || define('TB_ROLES', 'sp_user_roles');
defined('TB_USERS') || define('TB_USERS', 'sp_users');
defined('TB_TEAM') || define('TB_TEAM', 'sp_team');
defined('TB_TEAM_MEMBER') || define('TB_TEAM_MEMBER', 'sp_team_member');