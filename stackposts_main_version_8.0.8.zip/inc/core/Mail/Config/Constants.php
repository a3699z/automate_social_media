<?php
defined('TB_SMTP') || define('TB_SMTP', 'sp_smtp');