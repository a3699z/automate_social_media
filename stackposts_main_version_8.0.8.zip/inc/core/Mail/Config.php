<?php
return [
    'id' => 'mail',
    'folder' => 'core',
    'name' => 'Mail',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-envelope-open-text',
    'color' => '#00bba9',
    'role' => 1
   
]; 