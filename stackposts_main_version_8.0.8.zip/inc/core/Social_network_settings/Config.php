<?php
return [
    'id' => 'social_network_settings',
    'folder' => 'core',
    'name' => 'Social network settings',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-share-alt',
    'color' => '#002bff',
    'role' => 1
];