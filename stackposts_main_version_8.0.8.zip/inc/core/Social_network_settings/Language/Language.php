<?php return array (
  'Search' => 'Search',
  'Save' => 'Save',
  'Success' => 'Success',
  'Customize system interface' => 'Customize system interface',
  'Social network settings' => 'Social network settings',
);