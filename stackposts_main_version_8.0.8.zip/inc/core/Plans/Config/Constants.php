<?php
defined('TB_PLANS') || define('TB_PLANS', 'sp_plans');