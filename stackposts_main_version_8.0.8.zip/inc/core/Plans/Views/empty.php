<div class="mw-400 container d-flex align-items-center align-self-center h-100">
    <div>
        <div class="text-center px-4">
            <img class="mw-100 mh-300px" alt="" src="<?php _e( get_theme_url() ) ?>Assets/img/empty.png">
            <a href="<?php _ec( get_module_url("index/update") )?>" class="btn btn-primary btn-sm mt-4 b-r-30"><i class="fad fa-plus"></i> <?php _e("Add new")?></a>
        </div>
    </div>
</div>