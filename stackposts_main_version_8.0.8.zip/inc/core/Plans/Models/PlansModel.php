<?php
namespace Core\Plans\Models;
use CodeIgniter\Model;

class PlansModel extends Model
{
    
}
