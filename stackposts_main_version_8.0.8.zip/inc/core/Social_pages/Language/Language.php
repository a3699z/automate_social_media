<?php return array (
  'Facebook' => 'Facebook',
  'Instagram' => 'Instagram',
  'Youtube' => 'Youtube',
  'Tiktok' => 'Tiktok',
  'Twitter' => 'Twitter',
  'Pinterest' => 'Pinterest',
  'Save' => 'Save',
  'Customize system interface' => 'Customize system interface',
  'Social pages' => 'Social pages',
);