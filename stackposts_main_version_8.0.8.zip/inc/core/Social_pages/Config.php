<?php
return [
    'id' => 'social_pages',
    'folder' => 'core',
    'name' => 'Social pages',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'desc' => 'Customize system interface',
    'icon' => 'fad fa-share-alt-square',
    'color' => '#f4511e'
];