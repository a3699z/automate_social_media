<?php
defined('TB_GROUPS') || define('TB_GROUPS', 'sp_groups');