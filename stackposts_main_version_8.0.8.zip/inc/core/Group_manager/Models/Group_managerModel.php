<?php
namespace Core\Group_manager\Models;
use CodeIgniter\Model;

class Group_managerModel extends Model
{
    
}
