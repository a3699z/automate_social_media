<?php return array (
  'Search' => 'Search',
  'There are no drafts' => 'There are no drafts',
  'Compose a Post' => 'Compose a Post',
  'Are you sure to delete this items?' => 'Are you sure to delete this items?',
  'Post successed' => 'Post successed',
  'View post' => 'View post',
  'Advanced features' => 'Advanced features',
  'Draft posts' => 'Draft posts',
  'Delete failed' => 'Delete failed',
  'Success' => 'Success',
  'Customize system interface' => 'Customize system interface',
  'Drafts' => 'Drafts',
);