<?php
defined('TB_FAQS') || define('TB_FAQS', 'sp_faqs');