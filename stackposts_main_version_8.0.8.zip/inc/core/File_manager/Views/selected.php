<div class="fm-selected-media">
	<div class="items clearfix"></div>
	<div class="drophere border-dashed p-20 text-center fw-4 text-gray-400 text-uppercase">
		<span class="has-action"><?php _e("Drop here")?></span>
		<span class="no-action"><?php _e("Drag media here to post")?></span>
	</div>
</div>

<button type="button" class="btn btn-primary d-lg-none d-md-none d-sm-block mt-3 w-100 btn-open-filemanager"><?php _e("Select media")?></button>