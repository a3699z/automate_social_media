<?php
defined('TB_CAPTIONS') || define('TB_CAPTIONS', 'sp_captions');